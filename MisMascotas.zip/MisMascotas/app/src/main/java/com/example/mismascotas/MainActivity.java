package com.example.mismascotas;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ArrayList<Mascota> mascotas;
    //declaramos el reciclerview
    private RecyclerView listaMascotas;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        androidx.appcompat.widget.Toolbar miActionBar = findViewById(R.id.miActionBar);
        setSupportActionBar(miActionBar);//para que se vea bien en todas las pantalla
        //instanciamos el reciclerview
        listaMascotas = (RecyclerView) findViewById(R.id.rvMascotas);
        //creamos un linearlayout manager para las listas
        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setOrientation(LinearLayoutManager.VERTICAL);
       // GridLayoutManager glm = new GridLayoutManager(this, 2);
        listaMascotas.setLayoutManager(llm);//hacemos que el reciclerview se porte como linearL
        inicializarListaMascotas();
        inicializaAdaptador();

    }
    public MascotaAdaptador adaptador;
    public void inicializaAdaptador(){
        //inicializamos la instancia de listacontactos
        MascotaAdaptador adaptador = new MascotaAdaptador(mascotas,this);
        listaMascotas.setAdapter(adaptador);//seteamos el adapter
       // adaptador = new MascotaAdaptador(mascotas, this);
        //listaMascotas.setAdapter(adaptador);
    }

    public void inicializarListaMascotas(){
        mascotas = new ArrayList<Mascota>();//array objeto contactos
        mascotas.add(new Mascota(R.drawable.ic1,"Puffy", "Buldog",0));
        mascotas.add(new Mascota(R.drawable.ic2,"Ruffo", "Coker Spanish",0));
        mascotas.add(new Mascota(R.drawable.ic3,"Zulingo", "Fox Terrier", 0));
        mascotas.add(new Mascota(R.drawable.ic4,"Tobby", "Labrador",0));
        mascotas.add(new Mascota(R.drawable.ic5,"Hacho", "Pug",0));
        mascotas.add(new Mascota(R.drawable.ic6,"Loly", "Siberiano",0));
    }

    public void iradetalle(View v){//ir al ratin recicler
        Intent i = new Intent(this, DetalleMascota.class);
        startActivity(i);
       // finish();
    }
}