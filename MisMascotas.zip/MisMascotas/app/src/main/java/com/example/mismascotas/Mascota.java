package com.example.mismascotas;

public class Mascota {
    private String nombre;
    private String raza;
    private int ratin;
    private int foto;

    public Mascota(int foto, String nombre, String raza, int ratin) {
        this.foto = foto;
        this.nombre = nombre;
        this.raza = raza;
        this.ratin = ratin;
    }//constructor

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public int getRatin() {
        return ratin;
    }

    public void setRatin(int ratin) {
        this.ratin = ratin+1;
    }

    public int getFoto() { return foto;   }

    public void setFoto(int foto) { this.foto = foto; }
}
