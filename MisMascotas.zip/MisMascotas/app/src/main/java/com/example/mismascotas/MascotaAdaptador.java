package com.example.mismascotas;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class MascotaAdaptador extends RecyclerView.Adapter<MascotaAdaptador.MascotaViewHolder>{
    ArrayList<Mascota> mascotas;
    Activity activity;
    public MascotaAdaptador(ArrayList<Mascota> mascotas, Activity activity){
        this.mascotas = mascotas;
        this.activity = activity;
    }


    //inflar el layout y lo pasara al viewholder para que obtenga los views
    @NonNull
    @Override
    public MascotaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_mascota, parent, false);
        return new MascotaViewHolder(v) ;//pasamos el layout creado como un view
    }
    //asocia cada elemento de la vista con cada view
    @Override
    public void onBindViewHolder(@NonNull final MascotaViewHolder mascotaViewHolder, int position) {
        //seteamos cada uno de los elementos que trae la lista
        final Mascota mascota = mascotas.get(position);
        mascotaViewHolder.imgFoto.setImageResource(mascota.getFoto());//acceder al get foto
        mascotaViewHolder.tvNombreCV.setText(mascota.getNombre());
        mascotaViewHolder.tvRatinCV.setText(String.valueOf(mascota.getRatin()));
        mascotaViewHolder.tvRazaCV.setText(mascota.getRaza());

        mascotaViewHolder.btnlike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {//evento del boton like
                Toast.makeText(activity, "Diste like a: " + mascota.getNombre(),Toast.LENGTH_SHORT).show();
                mascotaViewHolder.tvRatinCV.setText("5");
            }
        });
        mascotaViewHolder.imgFoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {//toast muestra nombre al dar click en la foto
                Toast.makeText(activity, mascota.getNombre(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    public int getItemCount() {//cantidad de elementos de la lista
        return mascotas.size();
    }

    public static class MascotaViewHolder extends RecyclerView.ViewHolder{
        private ImageView imgFoto;
        private TextView tvNombreCV;
        private TextView tvRazaCV;
        private TextView tvRatinCV;
        private ImageButton btnlike;

        public MascotaViewHolder(@NonNull View itemView) {
            super(itemView);
            imgFoto      = (ImageView) itemView.findViewById(R.id.imgfoto);
            tvNombreCV   = (TextView) itemView.findViewById(R.id.tvNombreCV);
            tvRazaCV     = (TextView) itemView.findViewById(R.id.tvRazaCV);
            tvRatinCV    = (TextView) itemView.findViewById(R.id.tvRatinCV);
            btnlike      = (ImageButton) itemView.findViewById(R.id.btnlike);
        }
    }
}
